namespace ctrlx {
	config = {"variables":[{"id":"bPyFlag","address":"plc/app/Application/sym/GVL_BASE/bPyFlag","vtype":"bool8"},{"id":"strPyInfo","address":"plc/app/Application/sym/GVL_BASE/strPyInfo","vtype":"string"},{"id":"iPyStop","address":"plc/app/Application/sym/GVL_BASE/iPyStop","vtype":"int16"}]};
}
namespace ctrlx {

	//% fixedInstance whenUsed
	export const bPyFlag = new ctrlx.Variable(`plc/app/Application/sym/GVL_BASE/bPyFlag`, `bool8`);
	//% fixedInstance whenUsed
	export const strPyInfo = new ctrlx.Variable(`plc/app/Application/sym/GVL_BASE/strPyInfo`, `string`);
	//% fixedInstance whenUsed
	export const iPyStop = new ctrlx.Variable(`plc/app/Application/sym/GVL_BASE/iPyStop`, `int16`);

}