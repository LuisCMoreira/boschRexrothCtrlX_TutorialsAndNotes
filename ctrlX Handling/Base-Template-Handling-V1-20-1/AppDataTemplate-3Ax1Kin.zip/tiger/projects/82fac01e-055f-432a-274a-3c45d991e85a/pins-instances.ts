namespace pins {
	config = {"addressPrefix":"/fieldbuses/ethercat/master/instances/ethercatmaster/realtime_data/","pins":[]};
}
