ctrlx.strPyInfo.setValue("VISUAL Start DemoVisual")
let iCount = 0
let mvVel = 50
loops.main(function () {
    for (let index = 0; index < 4; index++) {
        loops.pause(1000)
        iCount = iCount + 1
        ctrlx.strPyInfo.setValue("Move Cycle  " + iCount)
        motion.Robot.movePositions(MoveType.ABSOLUTE, motion.pointStart.getValue(), mvVel, 1)
        motion.Robot.movePositions(MoveType.ABSOLUTE, motion.point1.getValue(), mvVel, 1)
        motion.Robot.movePositions(MoveType.ABSOLUTE, motion.point2.getValue(), mvVel, 1)
        motion.Robot.movePositions(MoveType.ABSOLUTE, motion.point3.getValue(), mvVel, 1)
    }
    ctrlx.strPyInfo.setValue("VISUAL Program finshed")
    control.exit(0)
})
