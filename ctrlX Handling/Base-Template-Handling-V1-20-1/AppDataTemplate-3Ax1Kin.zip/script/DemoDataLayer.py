#from ctrxpy import motion
#from ctrxpy import datalayer
import time

sNode_bTest = '/plc/app/Application/sym/GVL_BASE/bPyFlag'
sNode_sTest = '/plc/app/Application/sym/GVL_BASE/strPyInfo'
sNode_iStopPython = '/plc/app/Application/sym/GVL_BASE/iPyStop'

sStopMsg = '*** STOP signal received by python script => exit program ***'
i = 5
bTest = True
sTest = ""
iStop = 0
while (i > 0):
    sTest = "TEXT: Count down {}".format(i)
    i -= 1
    if bTest:
        bTest = False
    else:
        bTest = True
    datalayer.write(sNode_bTest, bTest)
    datalayer.write(sNode_sTest, sTest)
    print(sNode_sTest + sTest)
    time.sleep(1)
    iStop = datalayer.read(sNode_iStopPython)
    if (iStop != 0):
        datalayer.write(sNode_sTest, sStopMsg)
        break

datalayer.write(sNode_sTest, "*** Python script finished ***")
exit(0)
