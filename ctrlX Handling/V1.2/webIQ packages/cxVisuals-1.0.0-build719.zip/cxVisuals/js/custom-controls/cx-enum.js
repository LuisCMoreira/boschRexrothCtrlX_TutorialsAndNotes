/**
 * WebIQ Visuals widget template.
 *
 * Configuration options (default):
 *
 * {
 *     "class-name": "cx-enum", // {%= ui_type %}
 *     "name": null,
 *     "template": "custom/controls/cx-enum" // {%= template_path %}
 * }
 *
 * Explanation of configuration options:
 *
 * class-name {string}: Sets default CSS class applied on widget root element
 * name {string}: Name of widget set to data-name attribute
 * template {string}: Path to template file
 *
 * @version 1.2 changed by boschrexroth
 */
(function () {
    'use strict';

    // variables for reference in widget definition
    const templatePath = "custom/controls/cx-enum" // "{%= template_path %}"
    const uiType = "cx-enum"    // widget keyword (data-ui) {%= ui_type %}
    const className = uiType           // widget name in camel case {%= constructor_name %}
    const isContainer = false

    // example - default configuration
    const defaultConfig = {
        "class-name": uiType,
        "name": null,
        "template": templatePath,
        "label": uiType,
        "item": null
    };

    // setup module-logger
    const ENABLE_LOGGING = false //enable logging with 'log' function
    const RECORD_LOG = false //store logged messages in logger memory
    const logger = shmi.requires("visuals.tools.logging").createLogger(uiType, ENABLE_LOGGING, RECORD_LOG)
    const fLog = logger.fLog //force log - logs message even if logger is disabled
    const log = logger.log; //log message if logger is enabled

    // declare private functions - START
    // (CUSTOM ADDITION++)
    function enableListeners(self) {
        self.vars.listeners.forEach((l) => {
            l.enable();
        });
    }

    function disableListeners(self) {
        self.vars.listeners.forEach((l) => {
            l.disable();
        });
    }

    function updateValue(self, value) {
        const { elements } = self.vars;
        if (elements.bar && elements.value) {
            // Calculate
            const percentage = 100 * (value - self.vars.min) / (self.vars.max - self.vars.min);
            // Change bar value
            elements.value.textContent = `${Math.floor(percentage)}%`;
            // Change filled bar width
            elements.bar.style.width = `${percentage}%`;
        }
    }
    // (/CUSTOM ADDITION--)
    // declare private functions - END

    // definition of new widget extending BaseControl - START
    const definition = {
        className: className,
        uiType: uiType,
        isContainer: isContainer,
        // default configuration settings - all available options have to be initialized!
        config: defaultConfig,
        // instance variables
        vars: {
            // (CUSTOM ADDITION++)
            elements: { 
                //references for DOM elements accessed with JS code
                label: null, //element to display label text
                unit: null, //element to display unit text
                bar: null, //element of colored bar
                value: null //element to display item value
            },
            min: 0, //minimum value for item, will be replaced by actual item minimum if defined
            max: 100, //maximum value for item, will be replaced by actual item maximum if defined
            item: null, //reference for PLC item subscription token - will be set when widget is enabled
            listeners: [] //event listeners
            // (/CUSTOM ADDITION--)
        },
        // imports added at runtime
        imports: {
            // example - add import via shmi.requires(...)
            im: "visuals.session.ItemManager",
            // (CUSTOM ADDITION++)
            io: "visuals.io"
            // (/CUSTOM ADDITION--)
        },

        // array of custom event types fired by this widget
        events: [],

        // functions to extend or override the BaseControl prototype
        prototypeExtensions: {
            // called when config-file (optional) is loaded and template (optional) is inserted into base element
            onInit: function () {
                // (CUSTOM ADDITION++)
                log("onInit")
                const self = this,
                    { elements } = self.vars;

                // Store references to the DOM elements for performance reasons
                elements.label = shmi.getUiElement("label", self.element);
                elements.unit = shmi.getUiElement("unit", self.element);
                elements.bar = shmi.getUiElement("bar", self.element);
                elements.value = shmi.getUiElement("value", self.element);

                // Set label and unit
                if (elements.label) elements.label.textContent = shmi.localize(self.config.label);
                if (elements.unit) elements.unit.textContent = shmi.localize(self.config.unit);

                // add onClick handler to execute an function
                if (elements.bar) {
                    //get reference to Mouse- & TouchListener constructors
                    const { MouseListener, TouchListener } = self.imports.io;

                    // define the onClick handler
                    const handler = {
                        onClick: function () {
                            // Change bar color to random color
                            elements.bar.style.backgroundColor = `#${Math.floor(Math.random() * 16777215).toString(16)}`;
                        }
                    };

                    //create listeners for root element (=self.element) of the widget
                    self.vars.listeners.push(
                        new MouseListener(self.element, handler),
                        new TouchListener(self.element, handler)
                    );
                }
                // (CUSTOM ADDITION--)
            },
            // called when widget is enabled
            onEnable: function () {
                // (CUSTOM ADDITION++)
                log("onEnable")
                const self = this,
                    { im } = self.imports;
                enableListeners(self);

                // Subscribe to item updates
                if (self.config.item) {
                    self.vars.item = im.subscribeItem(self.config.item, self);
                }
                // (/CUSTOM ADDITION--)
            },
            // called when widget is disabled
            onDisable: function () {
                // (CUSTOM ADDITION++)
                log("onDisable")
                const self = this;
                disableListeners(self);
                // Stop listening to item, i.e. unsubscribe from item updates
                if (self.vars.item) {
                    self.vars.item.unlisten();
                    self.vars.item = null;
                }
                // (/CUSTOM ADDITION--)
            },
            // called when widget is locked - disable mouse- and touch-listeners
            onLock: function () {
                // (CUSTOM ADDITION++)
                log("onLock")
                const self = this;
                disableListeners(self);
                // (/CUSTOM ADDITION--)
            },
            // called when widget is unlocked - enable mouse- and touch-listeners
            onUnlock: function () {
                // (CUSTOM ADDITION++)
                log("onUnlock")
                const self = this;
                enableListeners(self);
                // (/CUSTOM ADDITION--)
            },
            // called by ItemManager when value of subscribed item changes and once on initial subscription
            onSetValue: function (value, type, name) {
                // (CUSTOM ADDITION++)
                log("onSetValue")
                const self = this;
                if (name === self.config.item)
                    updateValue(this, value);
                // (/CUSTOM ADDITION--)
            },
            // called by ItemManager to provide properties (min & max values etc.) of subscribed item
            onSetProperties: function (min, max, step, name, type, warnMin, warnMax, prewarnMin, prewarnMax, digits) {
                // (CUSTOM ADDITION++)
                log("onSetProperties" + `name:${name} type:${type} min:${min} max:${max}`)

                const self = this;
                self.vars.min = min;
                self.vars.max = max;
                // (/CUSTOM ADDITION--)
            },
            // called when widget is deleted - used for instance clean-up
            onDelete: function () {
                log("onDelete")
            }
        }
    };

    // definition of new widget extending BaseControl - END

    // generate widget constructor & prototype using the control-generator tool
    shmi.requires("visuals.tools.control-generator").generate(definition);
})();
