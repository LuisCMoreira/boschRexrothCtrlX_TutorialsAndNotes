namespace server {
	config = {"resources":[]};
}
